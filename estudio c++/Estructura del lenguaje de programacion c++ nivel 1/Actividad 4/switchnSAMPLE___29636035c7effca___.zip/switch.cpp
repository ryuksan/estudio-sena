#include <iostream>
#include <math.h>
using namespace std;

int main (){
float PORCENTG, COST, VALOR;
int REF, TALLA, CANTI, UTILI, UTIL;
char DESC[30], DISPONIBLE[20], TIPO[20];

cout<<"VENTA DE ZAPATOS \n ";
cout<<"digite la referencia del zapato... \n"; cin>>REF;
cin.ignore(256, '\n');
cout<<"digite una descripcion del zapato... \n"; cin.getline(DESC, 30);
cout<<"digite la talla ... \n"; cin>>TALLA;
cout<<"digite la letra si esta disponible o no para la venta S/N \n"; cin>>DISPONIBLE;
cout<<"digite el costo del zapato... \n"; cin>>COST;
cout<<"digita el precio de venta del zapato... \n"; cin>>VALOR;

	if (COST<=30000){
		 TIPO[0] = 'A';
			PORCENTG = 50;		
	} else if (COST>30000 && COST<=60000 ){
		 TIPO[0] = 'B';	
						PORCENTG = 40;
	} else if (COST>60000){
		 TIPO[0] = 'C';	
						PORCENTG = 30;
	}

system ("cls");

cout<<"\n \n LOS DATOS REGISTRADOS SON LOS SIGUIENTES \n ";
cout<<"\n REFERENCIA :	"<<REF;
cout<<"\n DESCRIPCION : 	"<<DESC;
cout<<"\n TALLA : 	"<<TALLA;
cout<<"\n DISPONIBILIDAD : 	"<<DISPONIBLE;

// la logica del SWITCH PARA determinar el mensaje del TIPO de zapato A,B o C
// SE VALIDA SEGUN LA VARIABLE TIPO
switch (TIPO[0]) //donde opción es la variable a comparar
{
    case 'A': 
	 cout<<"\n TIPO DE ZAPATO : A 	 \n ";
    break;
    case 'B':
     cout<<"\n TIPO DE ZAPATO : B 	 \n ";
    break;
    case 'C':
     cout<<"\n TIPO DE ZAPATO : C 	 \n ";
    break;
}

return 0;

}
